import { Course } from './course.js';

export const dataCourses = [
  new Course("Billar Masculino","Jose Reyes", 1),
  new Course("Biologia celular-teoria","Jesus Uribe", 3),
  new Course("Biologia celular-laboratorio","Adriana Rodriguez", 0),
  new Course("Ciborgs/Posthumanos: Tejidos entre ciencia y tecnología","Alba Avila", 2),
  new Course("Desarrollo de SW en equipo","Ruby Casallas", 3),
  new Course("Diseño y análisis de algoritmos","Ruben Manrique", 3),
  new Course("Laboratorios de maratones de programación","Nicolas Cardozo", 1),
  new Course("Robots del hoy y del mañana","Carlos Rodriguez", 2),
  new Course("Sistemas transaccionales","Claudia Jimenez", 3),
  new Course("Softbol","Jose Aguirre", 1)
] 
  